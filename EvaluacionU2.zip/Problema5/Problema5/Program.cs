﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Problema5
{
    class Program
    {
        static void hilo1()
        {
            Thread.Sleep(1000);
            Console.WriteLine("Terminó hilo 1");
        }
        static void hilo2()
        {
            Thread.Sleep(2000);
            Console.WriteLine("Terminó hilo 2");
        }
        static void hilo3()
        {
            Thread.Sleep(3000);
            Console.WriteLine("Terminó hilo 3");
        }
        static void hilo4()
        {
            Thread.Sleep(4000);
            Console.WriteLine("Terminó hilo 4");
        }
        static void hilo5()
        {
            Thread.Sleep(5000);
            Console.WriteLine("Terminó hilo 5");
        }
        static void hilo6()
        {
            Thread.Sleep(6000);
            Console.WriteLine("Terminó hilo 6");
        }
        static void hilo7()
        {
            Thread.Sleep(7000);
            Console.WriteLine("Terminó hilo 7");
        }
        static void hilo8()
        {
            Thread.Sleep(8000);
            Console.WriteLine("Terminó hilo 8");

        }
        static void hilo9()
        {
            Thread.Sleep(9000);
            Console.WriteLine("Terminó hilo 9");

        }
        static void hilo10()
        {
            Thread.Sleep(10000);
            Console.WriteLine("Terminó hilo 10");

        }
        static void Main(string[] args)
        {
            Thread t1 = new Thread(new ThreadStart(hilo1));
            Thread t2 = new Thread(new ThreadStart(hilo2));
            Thread t3 = new Thread(new ThreadStart(hilo3));
            Thread t4 = new Thread(new ThreadStart(hilo4));
            Thread t5 = new Thread(new ThreadStart(hilo5));
            Thread t6 = new Thread(new ThreadStart(hilo6));
            Thread t7 = new Thread(new ThreadStart(hilo7));
            Thread t8 = new Thread(new ThreadStart(hilo8));
            Thread t9 = new Thread(new ThreadStart(hilo9));
            Thread t10 = new Thread(new ThreadStart(hilo10));

            t1.Start();
            t2.Start();
            t3.Start();
            t4.Start();
            t5.Start();
            t6.Start();
            t7.Start();
            t8.Start();
            t9.Start();
            t10.Start();


            Console.ReadKey();
        }
    }
}
