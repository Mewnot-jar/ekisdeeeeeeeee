﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema2
{
    class Program
    {
        static void Main(string[] args)
        {

            ArrayList numeros = new ArrayList();
            int numero = 1;
            int numMayor = 0;
            int numMenor = 1999999999;
            int promedio = 0;
            int sumaArray = 0;
            while (numero != 0)
            {
                Console.WriteLine("Ingrese un numero: ");
                numero = Convert.ToInt32(Console.ReadLine());
                numeros.Add(numero);
            }
            numeros.Remove(0);

            for (int i = 0; i < numeros.Count; i++)
            {
                if (Convert.ToInt32(numeros[i]) > numMayor)
                {
                    numMayor = Convert.ToInt32(numeros[i]);
                }
                if (Convert.ToInt32(numeros[i]) < numMenor)
                {
                    numMenor = Convert.ToInt32(numeros[i]);
                }
                sumaArray += Convert.ToInt32(numeros[i]);
            }
            promedio = sumaArray / numeros.Count;
            Console.WriteLine("El numero mayor es: {0}", numMayor);
            Console.WriteLine("El numero menor es: {0}", numMenor);
            Console.WriteLine("El promedio del Array es: {0}", promedio);
            Console.ReadKey();
        }

    }
}
