﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema3
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList numeros = new ArrayList();
            int capacidad;

            Console.Write("Ingrese la capacidad del Array, recuerde que debe ser mayor a 10: ");
            capacidad = Convert.ToInt32(Console.ReadLine());
            while (capacidad < 10)
            {
                Console.Write("Ingrese la capacidad del Array, recuerde que debe ser mayor a 10: ");
                capacidad = Convert.ToInt32(Console.ReadLine());
            }

            for (int i = 0; i < capacidad; i++)
            {
                Console.Write("Ingrese un numero: ");
                numeros.Add(Convert.ToInt32(Console.ReadLine()));
            }
            for (int i = capacidad - 1; i >= 0; i--)
            {
                Console.WriteLine(numeros[i]);
                
            }
            Console.ReadKey();
        }
    }
}
